package com.safezone.admin.service;

import com.safezone.admin.model.Alerta;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.ChatClient;
import org.springframework.ai.chat.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.Generation;
import org.springframework.ai.chat.messages.Message;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class RecommendationServiceTest {

    private ChatClient chatClient;
    private RecommendationService recommendationService;

    @BeforeEach
    void setup() {
        chatClient = mock(ChatClient.class);
        recommendationService = new RecommendationService(chatClient);
    }

    @Test
    void testGerarRecomendacao() {
        //Mensagem esperada
        String expected = "Recomendo verificar o abrigo municipal mais próximo.";

        //Mock da resposta da IA
        Generation mockGeneration = new Generation(expected);
        ChatResponse mockResponse = new ChatResponse(List.of(mockGeneration));
        when(chatClient.call(any(Prompt.class))).thenReturn(mockResponse);

        //Cria alerta simulado
        Alerta alerta = new Alerta();
        alerta.setTipo("Inundação");
        alerta.setNivelRisco("Alto");
        alerta.setRegiao("Zona Sul - São Paulo");
        alerta.setDescricao("Ruas alagadas próximas à Avenida Interlagos.");
        alerta.setData(LocalDate.now());

        String resultado = recommendationService.gerarRecomendacao(alerta);

        // Verifica resultado
        assertEquals(expected, resultado);
    }
}