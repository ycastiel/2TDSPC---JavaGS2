package com.safezone.admin.service;

import com.safezone.admin.model.Abrigo;
import com.safezone.admin.repository.AbrigoRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AbrigoServiceTest {

    private AbrigoRepository abrigoRepository;
    private AbrigoService abrigoService;

    @BeforeEach
    void setup() {
        abrigoRepository = mock(AbrigoRepository.class);
        abrigoService = new AbrigoService(abrigoRepository);
    }

    @Test
    void testListarTodos() {
        when(abrigoRepository.findAll()).thenReturn(List.of(new Abrigo(), new Abrigo()));

        List<Abrigo> abrigos = abrigoService.listarTodos();

        assertEquals(2, abrigos.size());
        verify(abrigoRepository, times(1)).findAll();
    }

    @Test
    void testBuscarPorId_Encontrado() {
        Abrigo abrigo = new Abrigo();
        abrigo.setId(1L);
        when(abrigoRepository.findById(1L)).thenReturn(Optional.of(abrigo));

        Abrigo resultado = abrigoService.buscarPorId(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
    }

    @Test
    void testBuscarPorId_NaoEncontrado() {
        when(abrigoRepository.findById(42L)).thenReturn(Optional.empty());

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> {
            abrigoService.buscarPorId(42L);
        });

        assertEquals("Abrigo não encontrado com ID: 42", ex.getMessage());
    }

    @Test
    void testSalvar() {
        Abrigo abrigo = new Abrigo();
        abrigo.setNome("Abrigo Teste");

        when(abrigoRepository.save(abrigo)).thenReturn(abrigo);

        Abrigo resultado = abrigoService.salvar(abrigo);

        assertNotNull(resultado);
        assertEquals("Abrigo Teste", resultado.getNome());
    }

    @Test
    void testAtualizar() {
        Abrigo existente = new Abrigo();
        existente.setId(1L);
        existente.setNome("Antigo");

        Abrigo atualizado = new Abrigo();
        atualizado.setNome("Novo");
        atualizado.setEndereco("Rua A");
        atualizado.setCapacidade(100);
        atualizado.setOcupacaoAtual(50);
        atualizado.setStatus("Ativo");

        when(abrigoRepository.findById(1L)).thenReturn(Optional.of(existente));
        when(abrigoRepository.save(any())).thenReturn(atualizado);

        Abrigo resultado = abrigoService.atualizar(1L, atualizado);

        assertEquals("Novo", resultado.getNome());
        assertEquals("Rua A", resultado.getEndereco());
        verify(abrigoRepository, times(1)).save(existente);
    }

    @Test
    void testDeletar() {
        when(abrigoRepository.existsById(1L)).thenReturn(true);

        abrigoService.deletar(1L);

        verify(abrigoRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeletar_NaoExiste() {
        when(abrigoRepository.existsById(99L)).thenReturn(false);

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> {
            abrigoService.deletar(99L);
        });

        assertEquals("Abrigo não encontrado para exclusão.", ex.getMessage());
    }
}