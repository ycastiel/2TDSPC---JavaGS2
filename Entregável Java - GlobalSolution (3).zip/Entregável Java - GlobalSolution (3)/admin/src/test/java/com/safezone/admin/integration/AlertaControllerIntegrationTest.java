package com.safezone.admin.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safezone.admin.model.Alerta;
import com.safezone.admin.repository.AlertaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
public class AlertaControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private AlertaRepository alertaRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() {
        alertaRepository.deleteAll();
    }

    @Test
    void testCriarAlerta() throws Exception {
        Alerta alerta = new Alerta();
        alerta.setTipo("Incêndio");
        alerta.setDescricao("Fumaça intensa na região central.");
        alerta.setNivelRisco("Alto");
        alerta.setData(LocalDate.now());
        alerta.setRegiao("Zona Central - SP");

        mockMvc.perform(post("/api/alertas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(alerta)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.tipo", is("Incêndio")))
                .andExpect(jsonPath("$.regiao", containsString("SP")));
    }

    @Test
    void testListarTodos() throws Exception {
        Alerta a1 = new Alerta("Tempestade", "Chuvas intensas", "Moderado", LocalDate.now(), "Leste");
        Alerta a2 = new Alerta("Deslizamento", "Morros em risco", "Alto", LocalDate.now(), "Norte");

        alertaRepository.saveAll(List.of(a1, a2));

        mockMvc.perform(get("/api/alertas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(2)))
                .andExpect(jsonPath("$[1].tipo", is("Deslizamento")));
    }

    @Test
    void testAtualizarAlerta() throws Exception {
        Alerta existente = alertaRepository.save(
                new Alerta("Queimada", "Vegetação em chamas", "Alto", LocalDate.now(), "Zona Sul")
        );

        existente.setDescricao("Queimada controlada");
        existente.setNivelRisco("Moderado");

        mockMvc.perform(put("/api/alertas/" + existente.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(existente)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.descricao", containsString("controlada")))
                .andExpect(jsonPath("$.nivelRisco", is("Moderado")));
    }

    @Test
    void testDeletarAlerta() throws Exception {
        Alerta alerta = alertaRepository.save(
                new Alerta("Calor Extremo", "Temperaturas acima de 40º", "Alto", LocalDate.now(), "Centro")
        );

        mockMvc.perform(delete("/api/alertas/" + alerta.getId()))
                .andExpect(status().isNoContent());

        mockMvc.perform(get("/api/alertas/" + alerta.getId()))
                .andExpect(status().isNotFound());
    }
}
