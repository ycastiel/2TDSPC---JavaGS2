package com.safezone.admin.service;

import com.safezone.admin.model.Alerta;
import com.safezone.admin.repository.AlertaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AlertaServiceTest {

    private AlertaRepository alertaRepository;
    private RabbitMQSender rabbitMQSender;
    private RecommendationService recommendationService;
    private AlertaService alertaService;

    @BeforeEach
    void setup() {
        alertaRepository = mock(AlertaRepository.class);
        rabbitMQSender = mock(RabbitMQSender.class);
        recommendationService = mock(RecommendationService.class);

        alertaService = new AlertaService(alertaRepository, rabbitMQSender, recommendationService);
    }

    @Test
    void testSalvar_DeveSalvarEChamarRabbitMQEIA() {

        Alerta alerta = new Alerta();
        alerta.setDescricao("Alerta de teste");
        alerta.setNivelRisco("ALTO");
        alerta.setTipo("Inundação");
        alerta.setData(LocalDate.now());
        alerta.setRegiao("Zona Sul");


        when(alertaRepository.save(alerta)).thenReturn(alerta);
        when(recommendationService.gerarRecomendacao(alerta)).thenReturn("Recomendação gerada");

        Alerta resultado = alertaService.salvar(alerta);

        assertNotNull(resultado);
        verify(alertaRepository, times(1)).save(alerta);
        verify(rabbitMQSender, times(1)).enviarMensagem(alerta);
        verify(recommendationService, times(1)).gerarRecomendacao(alerta);
    }

    @Test
    void testBuscarPorId_Encontrado() {
        Alerta alerta = new Alerta();
        alerta.setId(1L);

        when(alertaRepository.findById(1L)).thenReturn(Optional.of(alerta));

        Alerta resultado = alertaService.buscarPorId(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
    }

    @Test
    void testBuscarPorId_NaoEncontrado() {
        when(alertaRepository.findById(99L)).thenReturn(Optional.empty());

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> {
            alertaService.buscarPorId(99L);
        });

        assertEquals("Alerta não encontrado com ID: 99", ex.getMessage());
    }

    @Test
    void testListarTodos() {
        when(alertaRepository.findAll()).thenReturn(List.of(new Alerta(), new Alerta()));

        List<Alerta> lista = alertaService.listarTodos();

        assertEquals(2, lista.size());
        verify(alertaRepository, times(1)).findAll();
    }

    @Test
    void testDeletar_Existente() {
        when(alertaRepository.existsById(1L)).thenReturn(true);

        alertaService.deletar(1L);

        verify(alertaRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeletar_NaoExistente() {
        when(alertaRepository.existsById(42L)).thenReturn(false);

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> {
            alertaService.deletar(42L);
        });

        assertEquals("Alerta não encontrado para exclusão.", ex.getMessage());
    }
}