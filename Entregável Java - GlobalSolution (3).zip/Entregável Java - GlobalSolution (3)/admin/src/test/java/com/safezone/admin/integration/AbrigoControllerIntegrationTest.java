package com.safezone.admin.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safezone.admin.model.Abrigo;
import com.safezone.admin.repository.AbrigoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
public class AbrigoControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private AbrigoRepository abrigoRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() {
        abrigoRepository.deleteAll();
    }

    @Test
    void testCriarAbrigo() throws Exception {
        Abrigo abrigo = new Abrigo();
        abrigo.setNome("Abrigo Teste");
        abrigo.setEndereco("Rua A");
        abrigo.setCapacidade(100);
        abrigo.setOcupacaoAtual(40);
        abrigo.setStatus("Ativo");

        mockMvc.perform(post("/api/abrigos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(abrigo)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.nome", is("Abrigo Teste")))
                .andExpect(jsonPath("$.capacidade", is(100)));
    }

    @Test
    void testBuscarTodos() throws Exception {
        Abrigo a1 = new Abrigo("Abrigo 1", "Rua 1", 100, 20, "Ativo");
        Abrigo a2 = new Abrigo("Abrigo 2", "Rua 2", 200, 50, "Cheio");

        abrigoRepository.saveAll(List.of(a1, a2));

        mockMvc.perform(get("/api/abrigos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(2)))
                .andExpect(jsonPath("$[0].nome", is("Abrigo 1")));
    }

    @Test
    void testAtualizarAbrigo() throws Exception {
        Abrigo existente = abrigoRepository.save(new Abrigo("Original", "Endereço", 80, 20, "Normal"));

        existente.setNome("Atualizado");
        existente.setCapacidade(150);

        mockMvc.perform(put("/api/abrigos/" + existente.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(existente)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nome", is("Atualizado")))
                .andExpect(jsonPath("$.capacidade", is(150)));
    }

    @Test
    void testDeletarAbrigo() throws Exception {
        Abrigo abrigo = abrigoRepository.save(new Abrigo("Remover", "Rua X", 50, 10, "Fechado"));

        mockMvc.perform(delete("/api/abrigos/" + abrigo.getId()))
                .andExpect(status().isNoContent());


        mockMvc.perform(get("/api/abrigos/" + abrigo.getId()))
                .andExpect(status().isNotFound());
    }
}
