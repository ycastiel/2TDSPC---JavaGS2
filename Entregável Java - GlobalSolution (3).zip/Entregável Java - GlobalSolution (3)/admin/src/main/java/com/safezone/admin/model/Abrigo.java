package com.safezone.admin.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Abrigo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "O nome é obrigatório.")
    private String nome;

    @NotBlank(message = "O endereço é obrigatório.")
    private String endereco;

    @Min(value = 1, message = "A capacidade mínima é 1.")
    private int capacidade;

    @Min(value = 0, message = "A ocupação não pode ser negativa.")
    private int ocupacaoAtual;

    @NotBlank(message = "O status é obrigatório.")
    private String status;

    public Abrigo() {}

    // ✅ Construtor usado nos testes
    public Abrigo(String nome, String endereco, int capacidade, int ocupacaoAtual, String status) {
        this.nome = nome;
        this.endereco = endereco;
        this.capacidade = capacidade;
        this.ocupacaoAtual = ocupacaoAtual;
        this.status = status;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public int getOcupacaoAtual() {
        return ocupacaoAtual;
    }

    public void setOcupacaoAtual(int ocupacaoAtual) {
        this.ocupacaoAtual = ocupacaoAtual;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

