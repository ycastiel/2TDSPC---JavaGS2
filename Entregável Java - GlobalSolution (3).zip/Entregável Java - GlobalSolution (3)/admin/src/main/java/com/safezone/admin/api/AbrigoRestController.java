package com.safezone.admin.api;

import com.safezone.admin.model.Abrigo;
import com.safezone.admin.service.AbrigoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/abrigos")
public class AbrigoRestController {

    private final AbrigoService abrigoService;

    public AbrigoRestController(AbrigoService abrigoService) {
        this.abrigoService = abrigoService;
    }

    @GetMapping
    public ResponseEntity<List<Abrigo>> listarTodos() {
        return ResponseEntity.ok(abrigoService.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Abrigo> buscarPorId(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(abrigoService.buscarPorId(id));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Abrigo> criar(@RequestBody Abrigo abrigo) {
        return ResponseEntity.status(201).body(abrigoService.salvar(abrigo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Abrigo> atualizar(@PathVariable Long id, @RequestBody Abrigo abrigo) {
        try {
            return ResponseEntity.ok(abrigoService.atualizar(id, abrigo));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        try {
            abrigoService.deletar(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
