package com.safezone.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafezoneAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafezoneAdminApplication.class, args);
	}

}
