package com.safezone.admin.service;

import com.safezone.admin.model.Alerta;
import com.safezone.admin.repository.AlertaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlertaService {

    private final AlertaRepository alertaRepository;
    private final RabbitMQSender rabbitMQSender;
    private final RecommendationService recommendationService;

    // Construtor com os 3 serviços
    public AlertaService(
            AlertaRepository alertaRepository,
            RabbitMQSender rabbitMQSender,
            RecommendationService recommendationService) {
        this.alertaRepository = alertaRepository;
        this.rabbitMQSender = rabbitMQSender;
        this.recommendationService = recommendationService;
    }

    public List<Alerta> listarTodos() {
        return alertaRepository.findAll();
    }

    public Alerta buscarPorId(Long id) {
        return alertaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Alerta não encontrado com ID: " + id));
    }

    public Alerta salvar(Alerta alerta) {
        alertaRepository.save(alerta);
        rabbitMQSender.enviarMensagem(alerta);

        String recomendacao = recommendationService.gerarRecomendacao(alerta);
        System.out.println("📢 Recomendação IA: " + recomendacao);

        return alerta;
    }

    public Alerta atualizar(Long id, Alerta alertaAtualizado) {
        Alerta existente = buscarPorId(id);
        existente.setTipo(alertaAtualizado.getTipo());
        existente.setDescricao(alertaAtualizado.getDescricao());
        existente.setNivelRisco(alertaAtualizado.getNivelRisco());
        existente.setData(alertaAtualizado.getData());
        existente.setRegiao(alertaAtualizado.getRegiao());

        alertaRepository.save(existente);
        rabbitMQSender.enviarMensagem(existente);

        String recomendacao = recommendationService.gerarRecomendacao(existente);
        System.out.println("📢 Recomendação IA: " + recomendacao);

        return existente;
    }

    public void deletar(Long id) {
        if (!alertaRepository.existsById(id)) {
            throw new EntityNotFoundException("Alerta não encontrado para exclusão.");
        }
        alertaRepository.deleteById(id);
    }
}