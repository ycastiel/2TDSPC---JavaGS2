package com.safezone.admin.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safezone.admin.model.Alerta;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQSender {

    private final RabbitTemplate rabbitTemplate;
    private final ObjectMapper objectMapper;

    public RabbitMQSender(RabbitTemplate rabbitTemplate, ObjectMapper objectMapper) {
        this.rabbitTemplate = rabbitTemplate;
        this.objectMapper = objectMapper;
    }

    public void enviarMensagem(Alerta alerta) {
        try {
            String alertaJson = objectMapper.writeValueAsString(alerta);
            rabbitTemplate.convertAndSend("alerta.fila", alertaJson);
            System.out.println("📤 Enviado para RabbitMQ: " + alertaJson);
        } catch (Exception e) {
            System.out.println("❌ Erro ao enviar mensagem para RabbitMQ: " + e.getMessage());
        }
    }
}
