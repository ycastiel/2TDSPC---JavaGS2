package com.safezone.admin.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

import org.springframework.ai.chat.ChatClient;
import org.springframework.ai.openai.OpenAiChatClient;
import org.springframework.ai.openai.api.OpenAiApi;

@Configuration
public class ChatClientConfig {

    @Bean
    public ChatClient chatClient() {
        // Pega as configs via application.properties
        String baseUrl = "https://openrouter.ai/api/v1";
        String apiKey = System.getenv("OPENROUTER_API_KEY");

        RestClient.Builder builder = RestClient.builder();

        OpenAiApi openAiApi = new OpenAiApi(baseUrl, apiKey, builder);

        return new OpenAiChatClient(openAiApi);
    }
}