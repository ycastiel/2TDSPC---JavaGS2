package com.safezone.admin.controller;

import com.safezone.admin.model.Alerta;
import com.safezone.admin.service.AlertaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/alertas")
public class AlertaController {

    private final AlertaService alertaService;

    public AlertaController(AlertaService alertaService) {
        this.alertaService = alertaService;
    }

    // LISTAR
    @GetMapping
    public String listarAlertas(Model model) {
        model.addAttribute("alertas", alertaService.listarTodos());
        return "alerta/list"; // templates/alerta/list.html
    }

    // FORM CADASTRO
    @GetMapping("/novo")
    public String mostrarFormularioCadastro(Model model) {
        model.addAttribute("alerta", new Alerta());
        return "alerta/form";
    }

    // SALVAR
    @PostMapping
    public String salvar(@Valid @ModelAttribute("alerta") Alerta alerta,
                         BindingResult result) {
        if (result.hasErrors()) {
            return "alerta/form";
        }
        alertaService.salvar(alerta);
        return "redirect:/alertas";
    }

    // FORM EDIÇÃO
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
        Alerta alerta = alertaService.buscarPorId(id);
        model.addAttribute("alerta", alerta);
        return "alerta/form";
    }

    // ATUALIZAR
    @PostMapping("/editar/{id}")
    public String atualizar(@PathVariable Long id,
                            @Valid @ModelAttribute("alerta") Alerta alerta,
                            BindingResult result) {
        if (result.hasErrors()) {
            return "alerta/form";
        }
        alertaService.atualizar(id, alerta);
        return "redirect:/alertas";
    }

    // DELETAR
    @GetMapping("/deletar/{id}")
    public String deletar(@PathVariable Long id) {
        alertaService.deletar(id);
        return "redirect:/alertas";
    }
}
