package com.safezone.admin.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safezone.admin.model.Alerta;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQListener {

    private final ObjectMapper objectMapper;

    public RabbitMQListener(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @RabbitListener(queues = "alerta.fila")
    public void consumir(String mensagem) {
        try {
            Alerta alerta = objectMapper.readValue(mensagem, Alerta.class);
            System.out.println("📥 Alerta recebido da fila:");
            System.out.println("➡ Tipo: " + alerta.getTipo());
            System.out.println("➡ Descrição: " + alerta.getDescricao());
            System.out.println("➡ Região: " + alerta.getRegiao());
            System.out.println("➡ Nível de Risco: " + alerta.getNivelRisco());
            System.out.println("➡ Data: " + alerta.getData());
        } catch (Exception e) {
            System.out.println("❌ Erro ao processar mensagem do RabbitMQ:");
            e.printStackTrace();
        }
    }
}
