package com.safezone.admin.controller;

import com.safezone.admin.model.Abrigo;
import com.safezone.admin.service.AbrigoService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/abrigos")
public class AbrigoController {

    private final AbrigoService abrigoService;

    public AbrigoController(AbrigoService abrigoService) {
        this.abrigoService = abrigoService;
    }

    // LISTAR TODOS
    @GetMapping
    public String listarAbrigos(Model model) {
        model.addAttribute("abrigos", abrigoService.listarTodos());
        return "abrigo/list"; // thymeleaf: templates/abrigo/list.html
    }

    //FORMULÁRIO DE NOVO ABRIGO
    @GetMapping("/novo")
    public String mostrarFormularioCadastro(Model model) {
        model.addAttribute("abrigo", new Abrigo());
        return "abrigo/form"; // thymeleaf: templates/abrigo/form.html
    }

    //SALVAR NOVO ABRIGO
    @PostMapping
    public String salvarAbrigo(@Valid @ModelAttribute("abrigo") Abrigo abrigo,
                               BindingResult resultado, Model model) {
        if (resultado.hasErrors()) {
            return "abrigo/form";
        }
        abrigoService.salvar(abrigo);
        return "redirect:/abrigos";
    }

    // FORMULÁRIO DE EDIÇÃO
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
        Abrigo abrigo = abrigoService.buscarPorId(id);
        model.addAttribute("abrigo", abrigo);
        return "abrigo/form";
    }

    // ATUALIZAR ABRIGO
    @PostMapping("/editar/{id}")
    public String atualizarAbrigo(@PathVariable Long id,
                                  @Valid @ModelAttribute("abrigo") Abrigo abrigo,
                                  BindingResult resultado) {
        if (resultado.hasErrors()) {
            return "abrigo/form";
        }
        abrigoService.atualizar(id, abrigo);
        return "redirect:/abrigos";
    }

    // DELETAR
    @GetMapping("/deletar/{id}")
    public String deletarAbrigo(@PathVariable Long id) {
        abrigoService.deletar(id);
        return "redirect:/abrigos";
    }
}
