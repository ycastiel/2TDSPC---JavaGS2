package com.safezone.admin.service;

import com.safezone.admin.model.Alerta;
import org.springframework.ai.chat.ChatClient;
import org.springframework.ai.chat.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecommendationService {

    private final ChatClient chatClient;

    public RecommendationService(ChatClient chatClient) {
        this.chatClient = chatClient;
    }

    public String gerarRecomendacao(Alerta alerta) {
        String mensagem = String.format(
                "Tipo de alerta: %s. Nível de risco: %s. Região: %s. Descrição: %s. Data: %s.",
                alerta.getTipo(),
                alerta.getNivelRisco(),
                alerta.getRegiao(),
                alerta.getDescricao(),
                alerta.getData()
        );

        UserMessage userMessage = new UserMessage(mensagem);
        Prompt prompt = new Prompt(List.of(userMessage));
        ChatResponse response = chatClient.call(prompt);

        return response.getResult().getOutput().getContent();
    }
}