package com.safezone.admin.service;

import com.safezone.admin.model.Abrigo;
import com.safezone.admin.repository.AbrigoRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AbrigoService {

    private final AbrigoRepository abrigoRepository;

    public AbrigoService(AbrigoRepository abrigoRepository) {
        this.abrigoRepository = abrigoRepository;
    }

    public List<Abrigo> listarTodos() {
        return abrigoRepository.findAll();
    }

    public Abrigo buscarPorId(Long id) {
        return abrigoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Abrigo não encontrado com ID: " + id));
    }

    public Abrigo salvar(Abrigo abrigo) {
        return abrigoRepository.save(abrigo);
    }

    public Abrigo atualizar(Long id, Abrigo abrigoAtualizado) {
        Abrigo existente = buscarPorId(id);
        existente.setNome(abrigoAtualizado.getNome());
        existente.setEndereco(abrigoAtualizado.getEndereco());
        existente.setCapacidade(abrigoAtualizado.getCapacidade());
        existente.setOcupacaoAtual(abrigoAtualizado.getOcupacaoAtual());
        existente.setStatus(abrigoAtualizado.getStatus());
        return abrigoRepository.save(existente);
    }

    public void deletar(Long id) {
        if (!abrigoRepository.existsById(id)) {
            throw new EntityNotFoundException("Abrigo não encontrado para exclusão.");
        }
        abrigoRepository.deleteById(id);
    }
}
