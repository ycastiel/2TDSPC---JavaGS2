package com.safezone.admin.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.io.Serializable;

@Entity
public class Alerta implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "O tipo do alerta é obrigatório.")
    private String tipo;

    @NotBlank(message = "A descrição é obrigatória.")
    private String descricao;

    @NotBlank(message = "O nível de risco é obrigatório.")
    private String nivelRisco;

    @NotNull(message = "A data do alerta é obrigatória.")
    private LocalDate data;

    @NotBlank(message = "A região é obrigatória.")
    private String regiao;

    public Alerta() {}

    // ✅ Construtor usado nos testes
    public Alerta(String descricao, String tipo, String nivelRisco, LocalDate data, String regiao) {
        this.descricao = descricao;
        this.tipo = tipo;
        this.nivelRisco = nivelRisco;
        this.data = data;
        this.regiao = regiao;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNivelRisco() {
        return nivelRisco;
    }

    public void setNivelRisco(String nivelRisco) {
        this.nivelRisco = nivelRisco;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public String getRegiao() {
        return regiao;
    }

    public void setRegiao(String regiao) {
        this.regiao = regiao;
    }
}
