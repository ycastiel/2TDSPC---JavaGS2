package com.safezone.admin.controller;

import com.safezone.admin.model.Alerta;
import com.safezone.admin.service.RecommendationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/recomendacao")
public class RecommendationController {

    private final RecommendationService recommendationService;

    public RecommendationController(RecommendationService recommendationService) {
        this.recommendationService = recommendationService;
    }

    @GetMapping("/teste")
    public ResponseEntity<String> testarRecomendacao() {
        Alerta alerta = new Alerta();
        alerta.setTipo("Inundação");
        alerta.setNivelRisco("Alto");
        alerta.setRegiao("Zona Sul - São Paulo");
        alerta.setDescricao("Ruas alagadas próximas à Avenida Interlagos. Possível risco de deslizamento.");
        alerta.setData(LocalDate.now());

        String recomendacao = recommendationService.gerarRecomendacao(alerta);
        return ResponseEntity.ok("💬 Recomendação IA:\n\n" + recomendacao);
    }
}
